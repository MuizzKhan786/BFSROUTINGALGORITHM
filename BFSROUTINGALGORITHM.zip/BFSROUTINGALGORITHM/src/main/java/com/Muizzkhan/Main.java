package com.Muizzkhan;

public class Main {
    public static void main(String[] args) {BFSROUTINGALGORITHM.launchApp(args); // <- Must match exact class name
    }
}